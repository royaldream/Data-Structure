#include<stdio.h>
void main()
{
int a,b,n;
printf("Enter Your First Value \n");
scanf("%d",&a);

printf("Enter Your Second Value \n");
scanf("%d",&b);

n=a;
a=b;
b=n;
printf("\tSwap value\t\n");
printf("Your First Value %d \n",a);
printf("Your Second Value %d",b);

}
