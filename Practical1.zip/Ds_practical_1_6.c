#include<stdio.h>
void main()
{
    int a[10];
    int n,i;
    int max;
    printf("ENTER YOUR ARRAY SIZE \n");
    scanf("%d",&n);
    printf("Enterv Your Array \n");
    for(i=0;i<n;i++)
    {
        printf("enter Your %d array value \n",i);
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        printf("\t%d\n",a[i]);
    }
    for(i=0;i<n;i++)
    {
        if(max<a[i])
        {
            max=a[i];
        }
    }
    printf("Maximum Array Values is %d",max);
}
