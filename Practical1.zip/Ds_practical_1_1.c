#include<stdio.h>
void main()
{
    printf("\tHello World \n");
}
