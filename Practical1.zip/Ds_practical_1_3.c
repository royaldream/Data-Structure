#include<stdio.h>
void main()
{
int a,b,i;
int ans;

printf("Enter Your raised Value \n");
scanf("%d",&a);
ans=a;
printf("Enter Your power Value \n");
scanf("%d",&b);
printf("\t%d\n",ans);
for(i=1;i<b;i++)
{

    ans=ans*a;
    printf("\t%d\n",ans);
}
printf("Your Answer is %d",ans);

}
