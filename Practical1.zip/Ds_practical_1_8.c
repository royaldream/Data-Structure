#include<stdio.h>
int insert(int a[],int b)
{
    int i,p,x;
    printf("Enter Your Position \n");
    scanf("%d",&p);
    printf("Enter Your Value \n");
    scanf("%d",&x);

    for(i=0;i<b;i++)
    {
        if(p==i)
        {
            for(i=b;i>p;i--)
            {
                a[i]=a[i-1];
            }
            a[i]=x;
            b++;
        }

    }
return a;
}
int del(int a[],int b)
{
    int i,p;
    printf("Enter Your Position For Delete\n");
    scanf("%d",&p);

    for(i=0;i<b;i++)
    {
        if(i==p)
        {
            for(i=p;i<b-1;i++)
            {
            a[i]=a[i+1];
            }
            b--;
        }

    }
return a;
}

int display(int a[],int b)
{int i;
    printf("\tYour Array Is\n");
    for(i=0;i<b;i++)
    {
        printf("\t%d\n",a[i]);
    }
    return a;
}

int search(int a[],int b)
{
        int i,x;
        printf("Enter Your Search Value \n");
        scanf("%d",&x);
        for(i=0;i<b;i++)
        {
            if(a[i]==x)
            {
                printf("Your Value Search %d INDEX and Value is %d\n",i,a[i]);
            }
        }
        return a;
}

void main()
{
    int i,n,x;


    printf("Enter Your Array Size\n");
    scanf("%d",&n);
    int b[n],a[n];
    for(i=0;i<n;i++)
    {
        printf("Enter Your %d value",i);
        scanf("%d",&a[i]);
        b[i]=a[i];
    }

    c:

    printf("\tEnter Your Choice\n");
    printf("Choice 1 Insert Array\n");
    printf("Choice 2 Delete Array\n");
    printf("Choice 3 Display Array\n");
    printf("Choice 4 Search Array\n");
    printf("Exit 0 \n");
    scanf("%d",&x);
    switch(x)
    {
        case 0:break;
        case 1: b[n]=insert(a,n);n++; goto c;break;
        case 2: b[n]=del(a,n);n--; goto c;break;
        case 3: b[n]=display(a,n); goto c;break;
        case 4: b[n]=search(a,n); goto c;break;
        default :break;
    }
}
