#include<stdio.h>
int swap(int a,int b)
{
    int n;
    n=a;
    a=b;
    b=n;
    printf("\tSwap value\t\n");
    printf("Your First Value %d \n",a);
    printf("Your Second Value %d",b);

}
int raised(int x,int y)
{
    int ans,i;

    ans=x;
    printf("\t%d\n",ans);
    for(i=1;i<y;i++)
    {
        ans=ans*x;
        printf("\t%d\n",ans);
    }
    return ans;
}
void main()
{
    int x,y;
    int a,b;
int ch;
c:
printf("\tEnter Your Choice\n");
printf("\t1 : Swap Value\n");
printf("\t2 : Power Value\n");
scanf("%d",&ch);
switch(ch)
{
case 1:
	    printf("Enter Your First Value \n");
	    scanf("%d",&x);

	    printf("Enter Your Second Value \n");
	    scanf("%d",&y);

	    swap(x,y);

		goto c;
		break ;

case 2: 
	   printf("Enter Your raised Value \n");
	   scanf("%d",&a);

	    printf("Enter Your power Value \n");
	    scanf("%d",&b);
	    int ans=raised(a,b);
	    printf("Your Answer is %d",ans);

		goto c;
		break ;
	case 0: break;
	default : break;
}
}
