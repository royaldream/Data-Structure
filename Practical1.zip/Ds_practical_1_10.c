#include<stdio.h>
#include<string.h>

struct student
{
    char name[50];
    int rollno;
    int m1,m2,m3;
};
void result(struct student st[],int no)
{
    int i=0;

        for(i=0;i<no;i++)
        {
            if(st[i].m1>=23 && st[i].m2 >=23 && st[i].m3 >=23)
            {
                printf("\t%s is Pass\n",st[i].name);
            }
            else
            {
                 printf("\t%s is Fail\n",st[i].name);
            }

        }
}
void result_rollno(struct student st[],int no,int x)
{
    int i=0;
    float per;
    for(i=0;i<no;i++)
    {
        if(st[i].rollno == x)
        {
            if(st[i].m1>=23 && st[i].m2 >=23 && st[i].m3 >=23)
            {
                printf("\t%s is Pass\n",st[i].name);
                per=(float)(st[i].m1+st[i].m2+st[i].m3)/2.1;
                printf("\n\t%s get Percentage %f\n",st[i].name,per);
            }
            else
            {
                 printf("\t%s is Fail\n",st[i].name);
            }

        }
    }

}
void result_name(struct student st[],int no,char y[])
{
    int i=0;
    float per;
    for(i=0;i<no;i++)
    {
        if(strcmp(st[i].name,y)==0)
        {
            if(st[i].m1>=23 && st[i].m2 >=23 && st[i].m3 >=23)
            {
                printf("\t%s is Pass\n",st[i].name);
                per=(float)(st[i].m1+st[i].m2+st[i].m3)/2.1;
                printf("\n\t%s get Percentage %f\n",st[i].name,per);
            }
            else
            {
                 printf("%\ts is Fail\n",st[i].name);
            }

        }
    }
}
void high_per(struct student  st[],int no)
{
    int i=0;
    int p;
    float per,max=0;
    for(i=0;i<no;i++)
    {
        per=(float)(st[i].m1+st[i].m2+st[i].m3)/2.1;
        if(max<per)
        {
            max=per;
            p=i;

        }
    }
    printf("%s get Higest Percentage %f\n",st[p].name,max);
    printf("\tRoll No is %d\n",st[p].rollno);
    printf("\tMarks 1 = %d\n",st[p].m1);
    printf("\tMarks 2 = %d\n",st[p].m2);
    printf("\tMarks 3 = %d\n",st[p].m3);


}

void display(struct student st[],int no,int x)
{

    int i=0;
    float per;
    int p;
    for(i=0;i<no;i++)
    {
        if(st[i].rollno == x)
        {
            if(st[i].m1>=23 && st[i].m2 >=23 && st[i].m3 >=23)
            {
                p=i;
                printf("%s is Pass\n",st[i].name);
                per=(float)(st[i].m1+st[i].m2+st[i].m3)/2.1;
                printf("\n%s get Percentage %f\n",st[i].name,per);
            }
            else
            {
		 p=i;
                 printf("%s is Fail\n",st[i].name);
            }

        }
    }

    printf("\tRoll No is %d\n",st[p].rollno);
    printf("\tMarks 1 = %d\n",st[p].m1);
    printf("\tMarks 2 = %d\n",st[p].m2);
    printf("\tMarks 3 = %d\n",st[p].m3);
}

void main()
{
    int n,i=0,choice;
    char name[50];
    int rn;
    printf("Enter Your Number Of Student\n");
    scanf("%d",&n);
    struct student s[n];
    printf("\tEnter Your Student Details\n\n");

    for(i=0;i<n;i++)
    {
        int p=i+1;
        printf("\nEnter Your %d Student Name :-  \n",p);
        scanf("%s",s[i].name);

        printf("\tStudent RollNo\t:-  ");
        scanf("%d",&s[i].rollno);

        printf("\tStudent Marks 1\t:-  ");
        scanf("%d",&s[i].m1);

        printf("\tStudent Marks 2\t:-  ");
        scanf("%d",&s[i].m2);

        printf("\tStudent Marks 3\t:-  ");
        scanf("%d",&s[i].m3);
    }
    c:
    printf("\nEnter Your Choice\n");
    printf("1 : display result of each student \n");
    printf("2 : display result of student for given rollno\n");
    printf("3 : display result of student for given name\n");
    printf("4 : display information of student who secures highest percentage\n");
    printf("5 : display information of student\n");
    printf("0 : Exit\n");
    scanf("%d",&choice);
    switch(choice)
    {
        case 1:
            result(s,n);
            goto c;
            break;
        case 2:
            printf("\tEnter Your Student Roll no\n\n");
            scanf("%d",&rn);
            result_rollno(s,n,rn);
            goto c;
            break;

        case 3:
            printf("\tEnter Your Student Name \n\n");
            scanf("%s",name);
            result_name(s,n,name);
            goto c;
            break;

        case 4:
            high_per(s,n);
            goto c;
            break;

        case 5:
            printf("Enter Your Student Roll no For given All Information\n");
            scanf("%d",&rn);
            display(s,n,rn);
            goto c;
            break;

        case 0:  break;
        default : break;
    }
}


