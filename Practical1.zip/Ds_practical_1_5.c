#include<stdio.h>
int add(int a,int b)
{
    int ans;
    ans=a+b;
    return ans;
}
int subtract(int a,int b)
{
    int ans;
    ans=a-b;
    return ans;

}
int multiply(int a,int b)
{
    int ans;
    ans=a*b;
    return ans;
}

float divide(int a,int b)
{
    float ans;
    ans=(float)(a/b);
    return ans;
}

void main()
{
    int a,b;
    int n;
    int ans;
    float x;

        printf("Enter Your First Value \n");
        scanf("%d",&a);

        printf("Enter Your Second Value \n");
        scanf("%d",&b);
c:
        printf("\tEnter Your choice \n");
        printf("Addition of Two Number choice 1 \n");
        printf("Subtract of Two Number choice 2 \n");
        printf("Multiply of Two Number choice 3 \n");
        printf("Divide   of Two Number choice 4 \n");
        printf("Exit                   choice 0 \n");
        scanf("%d",&n);


    switch(n)
    {
        case 1 : ans=add(a,b);
        printf("Your Answer is %d\n",ans);
        goto c;

        break;


        case 2 : ans=subtract(a,b);
                printf("Your Answer is %d\n",ans);
                goto c;
                 break;


        case 3 : ans=multiply(a,b);
                printf("Your Answer is %d\n",ans);
                goto c;
                     break;
        case 4 : x=divide(a,b);
                printf("Your Answer is %f\n",x);
                goto c;
                 break;

        case 0: break;
        default : break;
    }




}
