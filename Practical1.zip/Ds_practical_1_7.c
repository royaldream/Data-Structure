#include<stdio.h>
int max(int a[10],int n)
{
    int i,max;

    for(i=0;i<n;i++)
    {
        printf("\t%d\n",a[i]);
    }
    max=a[0];
    for(i=0;i<n;i++)
    {
        if(max<a[i])
        {
            max=a[i];
        }
    }
    return max;
}
void main()
{
    int a[10];
    int n,i;
    int maximum;
    printf("ENTER YOUR ARRAY SIZE \n");
    scanf("%d",&n);
    printf("\tEnter Your Array \n");

    for(i=0;i<n;i++)
    {
        printf("enter Your %d array value \n",i);
        scanf("%d",&a[i]);
    }
    maximum=max(a,n);

        printf("Maximum Array Values is %d",maximum);

}
